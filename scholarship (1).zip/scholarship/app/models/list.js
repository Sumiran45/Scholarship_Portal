const mongoose = require('mongoose')
const Schema = mongoose.Schema

const listSchema = new Schema({
    idscholar: {type: String, required: true},
    scholarshipname: {type: String, required: true},
    caste: {type: String, required: true},
    eligibility: {type: String, required: true},
    state: {type: String, required: true},
    govt: {type: String, required: true},
    image:{type: csv,required:true},
    link:{type:String,required:true}
}) 


module.exports = mongoose.model('List', listSchema)