function dashboardController(){
    //Factory function: function jo return karti h object
    return{
        index(req, res) {
            
            res.render('students/dashboard')
        }
    }
}

module.exports = dashboardController