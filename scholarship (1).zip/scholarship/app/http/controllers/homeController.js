const List = require('../../models/list')
function homeController(){
    //Factory function: function jo return karti h object
    return{
        async index(req, res) {
            
        const scholarships = await List.find()    
        return res.render('home', {scholarships: scholarships})
        // List.find().then(function (scholarships){
        //     console.log(scholarships)
        //     return res.render('home', {scholarships: scholarships})
        // })
               
        }
    }
}

module.exports = homeController