const authController = require('../app/http/controllers/authController')
const homeController = require('../app/http/controllers/homeController')
const dashboardController = require('../app/http/controllers/students/dashboardController')

function initRoutes(app){

    app.get('/', homeController().index)

    // (req, res)=>{
    //     res.render('home')
    // })
    
    app.get('/dashboard', dashboardController().index)
    
    app.get('/login', authController().login)
    app.get('/register', authController().register)
}

//logic of post routes will be inside controllers

module.exports = initRoutes