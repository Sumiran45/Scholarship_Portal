//import express package
const express = require('express')
const app = express()
const ejs = require('ejs')
const path = require('path')
const expressLayout = require('express-ejs-layouts')
const PORT = process.env.PORT || 3800
const mongoose = require('mongoose')


//  database connection with mongoose
const url = 'mongodb://localhost/scholarship';
 mongoose.connect(url, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }).then(() => console.log("connection successful"))
    .catch((err) => console.log(err))
    

//Assets
app.use(express.static('public'))


//set Template engine
app.use(expressLayout)
//ab express ko batana h ki humari jp template(views) file h wo kaha pr h
app.set('views', path.join(__dirname, '/resources/views'))
app.set('view engine', 'ejs')

require('./routes/web')(app)



app.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`)
})